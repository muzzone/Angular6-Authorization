export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAkyfrwCvVGH4_JfLdK2ycKAyzG3H6dV_A",
    authDomain: "ng-6-test.firebaseapp.com",
    databaseURL: "https://ng-6-test.firebaseio.com",
    projectId: "ng-6-test",
    storageBucket: "ng-6-test.appspot.com",
    messagingSenderId: "998619900216"
  }
};
